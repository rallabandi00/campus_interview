﻿using ActiveUp.Net.Mail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2.Utilities
{
    public class MailRepository
    {
        private Imap4Client _client = null;
        LogWriter objwriter = new LogWriter();

        public MailRepository(string mailServer, int port, bool ssl, string login, string password)
        {

            try
            {
                
                if (ssl)
                    Client.ConnectSsl(mailServer, port);
                else
                    Client.Connect(mailServer, port);
                Client.Login(login, password);
            }
            catch(Exception ex)
            {
                objwriter.WriteText(ex);
                throw;
            }
        }

        public IEnumerable<Message> GetAllMails(string mailBox)
        {
            try
            {
                return GetMails(mailBox, "ALL").Cast<Message>();
            }
            catch(Exception ex)
            {
                objwriter.WriteText(ex);
                throw;
            }
        }

        public IEnumerable<Message> GetUnreadMails(string mailBox)
        {
            try
            {
                return GetMails(mailBox, "UNSEEN").Cast<Message>();
            }
            catch(Exception ex)
            {
                objwriter.WriteText(ex);
                throw;
            }
        }

        protected Imap4Client Client
        {
            get
            {
                if (_client == null)
                    _client = new Imap4Client();
                return _client;
            }
        }

        private MessageCollection GetMails(string mailBox, string searchPhrase)
        {
            try
            {
                Mailbox mails = Client.SelectMailbox(mailBox);
                MessageCollection messages = mails.SearchParse(searchPhrase);
                return messages;
            }
            catch(Exception ex)
            {
                objwriter.WriteText(ex);
                throw;
            }
        }
    }
}
