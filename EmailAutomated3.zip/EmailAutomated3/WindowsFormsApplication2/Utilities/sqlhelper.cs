﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApplication2.Utilities
{
    public class sqlhelper
    {
        public void connectdb()
        {
            SqlConnection conndb = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);

        }
    }
}
