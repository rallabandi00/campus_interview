﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
namespace WindowsFormsApplication2.Utilities
{
    public class LogWriter
    {

        string configpath = ConfigurationSettings.AppSettings["LogPath"];
        public void WriteActivityLog(string text)
        {
            string dirpath = configpath + "\\" + DateTime.Now.ToString("ddMMyyyy");
            string filepath= dirpath+ "\\Log_" + DateTime.Now.ToString("ddMMyyyy") + ".txt";
            if(!Directory.Exists(dirpath))
            {
                Directory.CreateDirectory(dirpath);
            }
            if(!File.Exists(filepath))
            {
                File.Create(filepath).Close();
            }
            string content = DateTime.Now.ToString() + " : " + text+System.Environment.NewLine ;
            File.AppendAllText(filepath, content);
        }

        public void WriteText(Exception ex)
        {
            string dirpath = configpath + "\\" + DateTime.Now.ToString("ddMMyyyy");
            string filepath = dirpath + "\\Error_" + DateTime.Now.ToString("ddMMyyyy") + ".txt";
            if (!Directory.Exists(dirpath))
            {
                Directory.CreateDirectory(dirpath);
            }
            if (!File.Exists(filepath))
            {
                File.Create(filepath).Close();
            }
            string content = DateTime.Now.ToString() + " : " + ex.ToString() + System.Environment.NewLine;
            File.AppendAllText(filepath, content);
        }

    }
}
