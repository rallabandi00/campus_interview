﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication2.Utilities;
using System.Configuration;
using System.IO;
using EAGetMail;
using HtmlAgilityPack;
using System.Data.SqlClient;
namespace WindowsFormsApplication2
{
    public partial class Form2 : Form
    {
        string emailaddress = "";
        string username = "";
        string password = "";
        int portno = -1;
        bool isssl = false;
        LogWriter objwriter = new LogWriter();

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            button1_Click(null, null);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!backgroundWorker1.IsBusy)
            {
                btnstart.Enabled = false;
                btnstop.Enabled = true;
                backgroundWorker1.RunWorkerAsync();
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            //RunMailSync();
            ReceiveMail(emailaddress, username, password, isssl);

        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {

        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (isclosed == false)
            {
                btnstart.Enabled = true;
                btnstop.Enabled = false;
            }
        }


        public void WriteActicityLog(string text)
        {
            richTextBox1.BeginInvoke((MethodInvoker)delegate
            {
                richTextBox1.AppendText(DateTime.Now.ToString() + " : " + text + System.Environment.NewLine);
                objwriter.WriteActivityLog(text);
            });
        }

        protected void RunMailSync()
        {
            try
            {
                WriteActicityLog("Authentication" + System.Environment.NewLine);
                MailRepository rep = new MailRepository(emailaddress, portno, isssl, username, password);
                WriteActicityLog("Authentication Successfull" + System.Environment.NewLine);
                WriteActicityLog("FetchingMails" + System.Environment.NewLine);
                IEnumerable<ActiveUp.Net.Mail.Message> messages = rep.GetUnreadMails("Inbox");
                WriteActicityLog("Total no of unseen Mails : " + messages.Count().ToString() + System.Environment.NewLine);
                foreach (ActiveUp.Net.Mail.Message email in messages)
                {
                    if (backgroundWorker1.CancellationPending)
                    {
                        return;
                    }
                    WriteActicityLog("Processing Mail" + email.Subject + System.Environment.NewLine);
                    WriteActicityLog("body" + email.BodyHtml + System.Environment.NewLine);
                    //Response.Write(string.Format("<p>{0}: {1}</p><p>{2}</p>", email.From, email.Subject, email.BodyHtml.Text));
                    //if (email.Attachments.Count > 0)
                    //{
                    //    foreach (MimePart attachment in email.Attachments)
                    //    {
                    //        Response.Write(string.Format("<p>Attachment: {0} {1}</p>", attachment.ContentName, attachment.ContentType.MimeType));
                    //    }
                    //}
                }
            }
            catch (Exception ex)
            {

            }

        }

        public bool validation(ref string address, ref string username, ref string password, ref int portno, ref bool isssl)
        {
            int outportno = 0;
            bool outisssl = false;
            if (Convert.ToString(ConfigurationSettings.AppSettings["address"]).Trim().Length == 0)
            {
                MessageBox.Show("Please specify imap address in config file");
                return false;
            }
            else if (Convert.ToString(ConfigurationSettings.AppSettings["username"]).Trim().Length == 0)
            {
                MessageBox.Show("Please specify username in config file");
                return false;
            }
            else if (Convert.ToString(ConfigurationSettings.AppSettings["password"]).Trim().Length == 0)
            {
                MessageBox.Show("Please specify password in config file");
                return false;
            }
            else if (int.TryParse(Convert.ToString(ConfigurationSettings.AppSettings["portno"]), out outportno) == false)
            {
                MessageBox.Show("Please check port no in config file");
                return false;
            }
            else if (bool.TryParse(Convert.ToString(ConfigurationSettings.AppSettings["ssl"]), out outisssl) == false)
            {
                MessageBox.Show("Please specify true or false for ssl in config file");
                return false;
            }
            address = ConfigurationSettings.AppSettings["address"];
            username = ConfigurationSettings.AppSettings["username"];
            password = ConfigurationSettings.AppSettings["password"];
            portno = int.Parse(Convert.ToString(ConfigurationSettings.AppSettings["portno"]));
            isssl = bool.Parse(Convert.ToString(ConfigurationSettings.AppSettings["ssl"]));
            return true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (validation(ref emailaddress, ref username, ref password, ref portno, ref isssl))
            {
                timer1.Start();
                btnstart.Enabled = false;
                btnstop.Enabled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (backgroundWorker1.IsBusy)
            {
                DialogResult result = MessageBox.Show("Are you sure do you want to stop the process", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                if (result == DialogResult.Yes)
                {
                    timer1.Stop();

                    backgroundWorker1.CancelAsync();
                }
            }
        }

        public void ReceiveMail(string server, string user, string password, bool useSsl)
        {
            try
            {
                // Create a folder named "inbox" under current directory
                // to save the email retrieved.
                string localInbox = string.Format("{0}\\inbox", Directory.GetCurrentDirectory());
                // If the folder is not existed, create it.
                if (!Directory.Exists(localInbox))
                {
                    Directory.CreateDirectory(localInbox);
                }

                // To receive email from IMAP4 server, please change
                // ServerProtocol.Pop3 to ServerProtocol.Imap4 in MailServer constructor

                // To receive email with Exchange Web Service, please change
                // ServerProtocol.Pop3 to ServerProtocol.ExchangeEWS to MailServer constructor

                // To receive email with Exchange WebDAV, please change
                // ServerProtocol.Pop3 to ServerProtocol.ExchangeWebDAV to MailServer constructor

                // Exchange Server supports POP3/IMAP4 protocol as well, but in Exchange 2007
                // or later version, POP3/IMAP4 service is disabled by default. If you don't want to use POP3/IMAP4
                // to download email from Exchange Server, you can use Exchange Web Service (Exchange 2007-2019 or
                // later version) or WebDAV (Exchange 2000/2003) protocol.

                // Most modern email server require SSL/TLS connection, 
                // set useSsl to true is recommended.
                MailServer oServer = new MailServer(server, user, password, useSsl,
                    ServerAuthType.AuthLogin, ServerProtocol.Imap4);

                // POP3 port is 110, POP3 SSL port is 995
                // IMAP4 port is 143,  IMAP4 SSL port is 993.
                // EWS/WebDAV, please ignore Port property.
                if (oServer.Protocol == ServerProtocol.Pop3)
                {
                    oServer.Port = (useSsl) ? 995 : 110;
                }
                else if (oServer.Protocol == ServerProtocol.Imap4)
                {
                    oServer.Port = (useSsl) ? 993 : 143;
                }

                WriteActicityLog("Connecting server ...");

                MailClient oClient = new MailClient("TryIt");
                oClient.Connect(oServer);

                //unComment to get new email only.........................
                oClient.GetMailInfosParam.Reset();
                oClient.GetMailInfosParam.GetMailInfosOptions = GetMailInfosOptionType.NewOnly;
                
                StringBuilder builder = new StringBuilder();

                WriteActicityLog("Retreiving email list ...");
                MailInfo[] infos = oClient.GetMailInfos();
                MailInfo[] infotemp = infos; //infos.AsEnumerable().Where(r=>r.IMAP4MailFlags.Contains("Recent")).Select(r=>r).ToArray();
                WriteActicityLog("Total {0} unreademail(s) " + infotemp.Length.ToString());
                for (int i = 0; i < infotemp.Length; i++)
                {
                    MailInfo info = infos[i];
                    try
                    {
                        WriteActicityLog(string.Format("Checking {0}/{1} ... ", (i + 1).ToString(), infotemp.Length.ToString()));
                        // Generate an unqiue email file name based on date time.s
                        string fileName = "TestEmail" + i.ToString();
                        string fullPath = string.Format("{0}\\{1}", localInbox, fileName);

                        WriteActicityLog(string.Format("Downloading {0}/{1} ... ", (i + 1).ToString(), infotemp.Length.ToString()));
                        Mail oMail = oClient.GetMail(info);

                        string subject = oMail.Subject;
                        string body = oMail.HtmlBody;
                        string[] split = new string[1];
                        if ( oMail.Subject.Contains("wants to change their "))
                        {

                            int count = 0;
                            string headername = "";
                            string headername1 = "";
                            string headername2 = "";
                            string originaldate = "";
                            string requestdate = "";
                            string originalfromdate = "";
                            string originaltodate = "";
                            string requestfromdate = "";
                            string requesttodate = "";
                            HtmlWeb web = new HtmlWeb();
                            File.WriteAllText(Application.StartupPath + "\\tmp\\tmp.html", body);
                            HtmlAgilityPack.HtmlDocument doc = web.Load(Application.StartupPath + "\\tmp\\tmp.html");
                            var nodes = doc.DocumentNode.SelectNodes("//span[@style]");
                            for (int j = 0; j < nodes.Count; j++)
                            {
                                HtmlAttributeCollection collection = nodes[j].Attributes;
                                string headerfilter = "TEXT-DECORATION: none; COLOR: #484848";
                                string spliterfilter = @"FONT-FAMILY: ""Helvetica"",""sans-serif""; COLOR: #0a0a0a";
                                string datefilter = @"FONT-SIZE: 11.5pt; FONT-FAMILY: ""Helvetica"",""sans-serif""; COLOR: #9ca299";
                                string requestdatefilter = @"FONT-SIZE: 11.5pt; FONT-FAMILY: ""Helvetica"",""sans-serif""; COLOR: #484848";

                                //To get the Span Styles for Web Content.
                                for (int n = 0; n < collection.Count; n++)
                                {
                                    string style = collection[n].Name;
                                    string value = collection[n].Value;
                                    builder.Append(style + " " + value + System.Environment.NewLine);
                                }

                                if (collection.AsEnumerable().Where(r => r.Name == "style" && r.Value == headerfilter).Select(r => r).ToArray().Length > 0)
                                {
                                    if (count == 0)
                                    {
                                        headername = ReplaceNewLineSpaces(nodes[j].InnerText);
                                        count++;
                                    }
                                    else if (count == 1)
                                    {
                                        headername1 = ReplaceNewLineSpaces(nodes[j].InnerText);
                                        count++;
                                    }
                                    else if (count == 2)
                                    {
                                        headername2 = ReplaceNewLineSpaces(nodes[j].InnerText);
                                        split = headername2.Split(new char[] { '\n', '\r' });
                                        headername2 = "";
                                        for (int str = 0; str < split.Length; str++)
                                        {
                                            if (str == 0)
                                            {
                                                headername2 += split[str];
                                            }
                                            else
                                            {
                                                headername2 += split[str].Trim();
                                            }
                                        }
                                        count++;
                                    }
                                }
                                if (collection.AsEnumerable().Where(r => r.Name == "style" && r.Value == spliterfilter).Select(r => r).ToArray().Length > 0)
                                {
                                    count = 0;
                                }
                                if (collection.AsEnumerable().Where(r => r.Name == "style" && r.Value == datefilter).Select(r => r).ToArray().Length > 0)
                                {
                                    if (count == 0)
                                    {
                                        originaldate = ReplaceNewLineSpaces(nodes[j].InnerText);
                                        split = originaldate.Split(new char[] { '\n', '\r' });
                                        originaldate = "";
                                        for (int str = 0; str < split.Length; str++)
                                        {
                                            if (str == 0)
                                            {
                                                originaldate += split[str];
                                            }
                                            else
                                            {
                                                originaldate += split[str].Trim();
                                            }
                                        }
                                        split = originaldate.Split('-');
                                        if (split.Length > 1)
                                        {
                                            originalfromdate = split[0];
                                            originaltodate = split[1];
                                        }
                                        count++;
                                    }
                                    else if (count == 1)
                                    {
                                        count = 0;
                                    }
                                }
                                if (collection.AsEnumerable().Where(r => r.Name == "style" && r.Value == requestdatefilter).Select(r => r).ToArray().Length > 0)
                                {
                                    if (count == 0)
                                    {
                                        requestdate = ReplaceNewLineSpaces(nodes[j].InnerText);
                                        split = requestdate.Split(new char[] { '\n', '\r' });
                                        requestdate = "";
                                        for (int str = 0; str < split.Length; str++)
                                        {
                                            if (str == 0)
                                            {
                                                requestdate += split[str];
                                            }
                                            else
                                            {
                                                requestdate += split[str].Trim();
                                            }
                                        }
                                        split = requestdate.Split('-');
                                        if (split.Length > 1)
                                        {
                                            requestfromdate = split[0];
                                            requesttodate = split[1];
                                        }
                                    }
                                }
                            }
                            //Ovearall styles are avalible in below text.
                            File.WriteAllText(Application.StartupPath + "\\styles.txt", builder.ToString());
                            SqlConnection conndb = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
                            try
                            {
                                SqlCommand cmd = new SqlCommand("SP_Insert_Booking_Request1", conndb);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@Location", headername1);
                                cmd.Parameters.AddWithValue("@guestname", headername);
                                cmd.Parameters.AddWithValue("@propertyname", headername2);
                                cmd.Parameters.AddWithValue("@originalchekindate", originaldate);
                                cmd.Parameters.AddWithValue("@requesycheckoutdat", requestdate);
                                conndb.Open();
                                int k = cmd.ExecuteNonQuery();
                                conndb.Close();
                            }
                            catch (Exception ex)
                            {
                                objwriter.WriteText(ex);
                            }
                            StringBuilder strvaluew = new StringBuilder();
                            strvaluew.Append("HeaderValue1 : " + headername + System.Environment.NewLine);
                            strvaluew.Append("HeaderValue2 : " + headername1 + System.Environment.NewLine);
                            strvaluew.Append("HeaderValue3 : " + headername2 + System.Environment.NewLine);
                            strvaluew.Append("originaldate : " + originaldate + System.Environment.NewLine);
                            strvaluew.Append("requestdate : " + requestdate + System.Environment.NewLine);
                            strvaluew.Append("originalfromdate : " + originalfromdate + System.Environment.NewLine);
                            strvaluew.Append("originaltodate : " + originaltodate + System.Environment.NewLine);
                            strvaluew.Append("requestfromdate : " + requestfromdate + System.Environment.NewLine);
                            strvaluew.Append("requesttodate : " + requesttodate + System.Environment.NewLine);

                            File.WriteAllText(Application.StartupPath + "\\Values.txt", strvaluew.ToString());
                            //var document = new HtmlDocument(body);s
                            ////doc.Load(htmlFile);
                            // XmlDocument xmldoc = new XmlDocument();
                            //xmldoc.LoadXml(body);
                        }
                        else if (oMail.Subject.Contains("Reservation confirmed"))
                        {

                        }
                        // Save mail to local file
                        oMail.SaveAs(fullPath, true);
                        oClient.MarkAsRead(info, true);
                    }
                    catch(Exception ex)
                    {
                        objwriter.WriteText(ex);
                    }
                    //// Mark the email as deleted on server.
                    //Console.WriteLine("Deleting ... {0}/{1}", i + 1, infos.Length);
                    //oClient.Delete(info);
                }
                WriteActicityLog("Disconnecting ...");
                // Delete method just mark the email as deleted, 
                // Quit method expunge the emails from server permanently.
                oClient.Quit();
                WriteActicityLog("Completed!");
            }
            catch (Exception ep)
            {
                objwriter.WriteText(ep);
            }
        }

        public string ReplaceNewLineSpaces(string str)
        {
            return str;
        }

        bool isclosed = false;

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult disresul = MessageBox.Show("Are you Sure Do You Want to Close", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if(disresul==DialogResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                if(backgroundWorker1.IsBusy)
                {
                    backgroundWorker1.CancelAsync();
                    isclosed = true;
                }
            }
        }
    }
}
